"""
Tasks App Package
This file marks the tasks folder as a Python package.
"""
